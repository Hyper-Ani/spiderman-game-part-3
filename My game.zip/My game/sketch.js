

var s1, s2;
var bg1, bg2;
var goblin;


function preload(){
s1= loadImage("");
s2=

}

function setup() {
  createCanvas(800,400);
  createSprite(400, 200, 50, 50);
}

function draw() {
  background(255,255,255);  
  drawSprites();
}